package com.Mega_App.Food_Delivery_App.model

data class Restaurant(
    val restaurantId: String,
    val restaurantName : String,
    val restaurantRating: String,
    val restaurantPrice: String,
    val restaurantImage: String
)