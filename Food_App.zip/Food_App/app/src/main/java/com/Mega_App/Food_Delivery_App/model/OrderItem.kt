package com.Mega_App.Food_Delivery_App.model

data class OrderItem (
    val itemName : String,
    val itemPrice: String
)